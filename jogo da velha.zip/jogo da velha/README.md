# Projeto desenvolvido no curso FORMAÇÃO DEV DA COD3R
Projeto simples usando HTML, CSS, JavaScript e explorando a dinâmica de inserir maior numero  de casas para o tabuleiro, aumentando a dificuldade do jogo para os participantes.


## Tecnologias que estou explorando hoje
Trilhando a road trip de todo desenvolvedor. Antes tarde do que nunca e nenhum troll fica pra trás é o meu lema.😅

![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![Javascript](https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)

[![Marttelo's GitHub stats](https://github-readme-stats.vercel.app/api?username=MARTTELO&&hide=prs,issues,contribs&show_icons=true&theme=radical)](https://github.com/anuraghazra/github-readme-stats)
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=MARTTELO&langs_count=8&layout=compact&theme=radical)](https://github.com/anuraghazra/github-readme-stats)

